from turtle import width
import pygame, sys
import os
import random

vidas = 3                                                
pontos = 0                                                       
frutas = ['banana', 'maça', 'melancia', 'pera', 'hamburguer']    


WIDTH = 800
HEIGHT = 500
FPS = 6                                                 
pygame.init()
pygame.display.set_caption('Vikings.PY')
gameDisplay = pygame.display.set_mode((WIDTH, HEIGHT))   
clock = pygame.time.Clock()

BRANCO = (255,255,255)

fundo = pygame.image.load('frutas.jpg')                                  
font = pygame.font.Font(os.path.join(os.getcwd(), 'comic.ttf'), 42)
texto = font.render('Pontos : ' + str(pontos), True, (255, 255, 255))                     


def gerar_random_frutas(fruta):
    fruta_caminho = "images/" + fruta + ".png"
    data[fruta] = {
        'img': pygame.image.load(fruta_caminho),
        'x': random.randint(100,500),          
        'y': 800,
        'speed_x': random.randint(-10,10),      
        'speed_y': random.randint(-80, -60),   
        'throw': False,                         
        't': 0,                                 
        'hit': False,
    }

    if random.random() >= 0.75:     
        data[fruta]['throw'] = True
    else:
        data[fruta]['throw'] = False


data = {}
for fruta in frutas:
    gerar_random_frutas(fruta)

def esconder_vidas(x, y):
    gameDisplay.blit(pygame.image.load("images/coraçao.png"), (x, y))


font_name = pygame.font.match_font('comic.ttf')
def draw_text(display, text, size, x, y):
    font = pygame.font.Font(font_name, size)
    text_surface = font.render(text, True, BRANCO)
    text_rect = text_surface.get_rect()
    text_rect.midtop = (x, y)
    gameDisplay.blit(text_surface, text_rect)

#vidas
def desenho_vidas(display, x, y, lives, image) :
    for i in range(lives) :
        img = pygame.image.load(image)
        img_rect = img.get_rect()       
        img_rect.x = int(x - 50 * i)    
        img_rect.y = y                  
        display.blit(img, img_rect)


def mostar_tela_gameover():
    gameDisplay.blit(fundo, (0,0))
    draw_text(gameDisplay, "VIKINGS.PY", 90, WIDTH / 2, HEIGHT / 4)
    if not game_over :
        draw_text(gameDisplay,"Pontuação : " + str(pontos), 50, WIDTH / 2, HEIGHT /2)

    draw_text(gameDisplay, "Aperte A para começar ", 64, WIDTH / 2, HEIGHT * 3 / 4)
    pygame.display.flip()
    esperar = True
    while esperar:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.KEYUP:
                esperar = False

#Loop do jogo
round_um = True
game_over = True        
jogo = True     

while jogo :
    if game_over :
        if round_um :
            mostar_tela_gameover()
            round_um = False
        game_over = False
        vidas = 3
        desenho_vidas(gameDisplay, 690, 5, vidas, 'images/coraçao.png')
        pontos = 0

    for event in pygame.event.get():
        
        if event.type == pygame.QUIT:
            jogo = False

    gameDisplay.blit(fundo, (0, 0))
    gameDisplay.blit(texto, (0, 0))
    desenho_vidas(gameDisplay, 690, 5, vidas, 'images/coraçao.png')

    for key, valor in data.items():
        if valor['throw']:
            valor['x'] += valor['speed_x']          
            valor['y'] += valor['speed_y']          
            valor['speed_y'] += (1 * valor['t'])    
            valor['t'] += 1                         

            if valor['y'] <= 800:
                gameDisplay.blit(valor['img'], (valor['x'], valor['y']))    
            else:
                gerar_random_frutas(key)

            mouse_posição = pygame.mouse.get_pos()   

            if not valor['hit'] and mouse_posição[0] > valor['x'] and mouse_posição[0] < valor['x']+60 \
                    and mouse_posição[1] > valor['y'] and mouse_posição[1] < valor['y']+60:
                if key == 'hamburguer':
                    vidas -= 1
                    if vidas == 0:
                        
                        esconder_vidas(690, 15)
                    elif vidas == 1 :
                        esconder_vidas(725, 15)
                    elif vidas == 2 :
                        esconder_vidas(760, 15)
                    
                    if vidas < 0 :
                        mostar_tela_gameover()
                        game_over = True

                    mordida_fruta_caminho = "images/hamburguer_mordido.png"
                    pygame.mixer.init()
                    pygame.mixer.music.load('mordida 2.mp3')
                    pygame.mixer.music.play()

                    pygame.mixer.music.set_volume(0.3)
                else:
                    mordida_fruta_caminho = "images/" + "mordida_" + key + ".png"
                    pygame.mixer.init()
                    pygame.mixer.music.load('mordida.mp3')
                    pygame.mixer.music.play()

                    pygame.mixer.music.set_volume(0.3)
                    

                valor['img'] = pygame.image.load(mordida_fruta_caminho)
                valor['speed_x'] += 10
                if key != 'hamburguer' :
                    pontos += 1
                texto = font.render('Pontos : ' + str(pontos), True, (255, 255, 255))
                valor['hit'] = True
        else:
            gerar_random_frutas(key)

    pygame.display.update()
    clock.tick(FPS)      # keep loop running at the right speed (manages the frame/second. The loop should update afer every 1/12th pf the sec
                        

pygame.quit()
